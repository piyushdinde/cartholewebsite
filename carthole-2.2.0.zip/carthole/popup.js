// ============================================
// CARTHOLE 2.2.0 - Multi-platform Expense Tracker
// Supports: Zepto, Blinkit, Swiggy Instamart
// ============================================

const MONTH_MAP = {
  'Jan': 0, 'Feb': 1, 'Mar': 2, 'Apr': 3, 'May': 4, 'Jun': 5,
  'Jul': 6, 'Aug': 7, 'Sep': 8, 'Oct': 9, 'Nov': 10, 'Dec': 11
};

const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

const PLATFORM_CONFIG = {
  zepto: {
    name: 'Zepto',
    url: 'https://www.zepto.com/account',
    urlPattern: 'zepto.com',
    accountPath: '/account',
    color: '#8B2FC9',
    cacheKey: 'zeptoOrders',
    lastFetchKey: 'zeptoLastFetch',
    usesGmail: false
  },
  blinkit: {
    name: 'Blinkit',
    url: 'https://blinkit.com/account/orders',
    urlPattern: 'blinkit.com',
    accountPath: '/account/orders',
    color: '#f0c14b',
    cacheKey: 'blinkitOrders',
    lastFetchKey: 'blinkitLastFetch',
    usesGmail: false
  },
  instamart: {
    name: 'Instamart',
    url: 'https://www.swiggy.com/instamart',
    urlPattern: 'swiggy.com',
    color: '#FC8019',
    cacheKey: 'instamartOrders',
    lastFetchKey: 'instamartLastFetch',
    gmailTokenKey: 'gmailToken',
    gmailEmailKey: 'gmailEmail',
    usesGmail: true
  }
};

let currentPlatform = 'zepto';
let computedData = null;
let isFetching = false;
let progressInterval = null;

// Progress bar controller
const ProgressBar = {
  currentProgress: 0,
  targetProgress: 0,
  
  start(platform) {
    this.currentProgress = 0;
    this.targetProgress = 0;
    
    const bar = document.getElementById('progressBar');
    const icon = document.getElementById('loaderIcon');
    const title = document.getElementById('loaderTitle');
    const subtitle = document.getElementById('loaderSubtitle');
    
    bar.className = 'progress-bar ' + platform;
    bar.style.width = '0%';
    
    // Set platform-specific icons and text
    if (platform === 'instamart') {
      icon.textContent = '📧';
      title.textContent = 'Scanning Gmail';
      subtitle.textContent = 'Connecting...';
    } else if (platform === 'zepto') {
      icon.textContent = '🛒';
      title.textContent = 'Fetching Orders';
      subtitle.textContent = 'Loading Zepto data...';
    } else {
      icon.textContent = '🛒';
      title.textContent = 'Fetching Orders';
      subtitle.textContent = 'Loading Blinkit data...';
    }
    
    // Start smooth animation
    if (progressInterval) clearInterval(progressInterval);
    progressInterval = setInterval(() => this.animate(), 100);
  },
  
  setPhase(phase, message) {
    const subtitle = document.getElementById('loaderSubtitle');
    subtitle.textContent = message;
    
    // Set target progress based on phase
    const phases = {
      'connecting': 15,
      'searching': 30,
      'loading': 45,
      'processing': 65,
      'analyzing': 80,
      'finalizing': 92
    };
    
    this.targetProgress = phases[phase] || this.targetProgress;
  },
  
  animate() {
    if (this.currentProgress < this.targetProgress) {
      // Smooth increment towards target
      const diff = this.targetProgress - this.currentProgress;
      const increment = Math.max(0.5, diff * 0.1);
      this.currentProgress = Math.min(this.currentProgress + increment, this.targetProgress);
      
      const bar = document.getElementById('progressBar');
      if (bar) bar.style.width = this.currentProgress + '%';
    }
  },
  
  complete() {
    if (progressInterval) {
      clearInterval(progressInterval);
      progressInterval = null;
    }
    
    this.currentProgress = 100;
    const bar = document.getElementById('progressBar');
    const subtitle = document.getElementById('loaderSubtitle');
    
    if (bar) bar.style.width = '100%';
    if (subtitle) subtitle.textContent = 'Complete!';
  },
  
  stop() {
    if (progressInterval) {
      clearInterval(progressInterval);
      progressInterval = null;
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  const tabZepto = document.getElementById('tabZepto');
  const tabBlinkit = document.getElementById('tabBlinkit');
  const tabInstamart = document.getElementById('tabInstamart');
  const fetchBtn = document.getElementById('fetchBtn');
  const cacheViewBtn = document.getElementById('cacheViewBtn');
  const cacheDownloadBtn = document.getElementById('cacheDownloadBtn');
  const downloadBtn = document.getElementById('downloadBtn');
  const gmailConnectBtn = document.getElementById('gmailConnectBtn');
  const gmailDisconnectBtn = document.getElementById('gmailDisconnectBtn');
  
  // Initialize
  switchPlatform('zepto');
  
  // Tab click handlers
  tabZepto.addEventListener('click', () => {
    if (!isFetching) switchPlatform('zepto');
  });
  
  tabBlinkit.addEventListener('click', () => {
    if (!isFetching) switchPlatform('blinkit');
  });
  
  tabInstamart.addEventListener('click', () => {
    if (!isFetching) switchPlatform('instamart');
  });
  
  // Fetch button
  fetchBtn.addEventListener('click', handleFetch);
  
  // Gmail connect button (Instamart)
  gmailConnectBtn.addEventListener('click', handleGmailConnect);
  
  // Gmail disconnect button (Instamart)
  gmailDisconnectBtn.addEventListener('click', handleGmailDisconnect);
  
  // Cache buttons
  cacheViewBtn.addEventListener('click', () => {
    const config = PLATFORM_CONFIG[currentPlatform];
    chrome.storage.local.get([config.cacheKey], (data) => {
      if (data[config.cacheKey]) {
        displayResults(data[config.cacheKey], currentPlatform);
      }
    });
  });
  
  cacheDownloadBtn.addEventListener('click', () => {
    const config = PLATFORM_CONFIG[currentPlatform];
    chrome.storage.local.get([config.cacheKey], (data) => {
      if (data[config.cacheKey]) {
        const analytics = computeAnalytics(data[config.cacheKey], currentPlatform);
        downloadCSV(analytics, currentPlatform);
      }
    });
  });
  
  // Download button
  downloadBtn.addEventListener('click', () => {
    if (computedData) {
      downloadCSV(computedData, currentPlatform);
    }
  });
});

function switchPlatform(platform) {
  currentPlatform = platform;
  const config = PLATFORM_CONFIG[platform];
  
  // Update tabs
  document.getElementById('tabZepto').classList.toggle('active', platform === 'zepto');
  document.getElementById('tabBlinkit').classList.toggle('active', platform === 'blinkit');
  document.getElementById('tabInstamart').classList.toggle('active', platform === 'instamart');
  
  // Show/hide Gmail sections for Instamart
  const gmailConnect = document.getElementById('gmailConnect');
  const gmailConnected = document.getElementById('gmailConnected');
  const instructions = document.getElementById('instructions');
  const fetchBtn = document.getElementById('fetchBtn');
  
  if (platform === 'instamart') {
    // Check if Gmail is connected
    chrome.storage.local.get([config.gmailTokenKey, config.gmailEmailKey], (data) => {
      if (data[config.gmailTokenKey] && data[config.gmailEmailKey]) {
        // Gmail is connected - show connected state and fetch button
        gmailConnect.classList.remove('active');
        gmailConnected.classList.add('active');
        instructions.style.display = 'none';
        fetchBtn.style.display = 'block';
        fetchBtn.className = 'instamart';
        fetchBtn.textContent = '🔄 REFRESH DATA';
        document.getElementById('gmailEmail').textContent = data[config.gmailEmailKey];
        document.getElementById('statusText').textContent = 'Click Refresh Data to fetch orders from Gmail';
      } else {
        // Gmail not connected - show connect button
        gmailConnect.classList.add('active');
        gmailConnected.classList.remove('active');
        instructions.style.display = 'none';
        fetchBtn.style.display = 'none';
        document.getElementById('statusText').textContent = 'Connect Gmail to fetch Instamart orders';
      }
    });
  } else {
    // Non-Instamart platforms
    gmailConnect.classList.remove('active');
    gmailConnected.classList.remove('active');
    instructions.style.display = 'block';
    fetchBtn.style.display = 'block';
    fetchBtn.textContent = '📊 FETCH DETAILS';
    
    // Update fetch button style
    fetchBtn.className = platform;
    
    // Update instructions
    const instructionLink = document.getElementById('instructionLink');
    instructions.className = 'instructions' + (platform === 'blinkit' ? ' blinkit' : '');
    instructionLink.href = config.url;
    instructionLink.textContent = config.name + (platform === 'zepto' ? ' Account Page' : ' Orders Page');
    
    // Show/hide Blinkit note
    const blinkitNote = document.getElementById('blinkitNote');
    blinkitNote.style.display = platform === 'blinkit' ? 'block' : 'none';
  }
  
  // Update total row and download button
  document.getElementById('totalRow').className = 'total-row ' + platform;
  document.getElementById('downloadBtn').className = 'download-btn ' + platform;
  
  // Update cache view button
  const cacheViewBtnClass = platform === 'blinkit' ? ' blinkit' : (platform === 'instamart' ? ' instamart' : '');
  document.getElementById('cacheViewBtn').className = 'cache-btn view' + cacheViewBtnClass;
  
  // Reset UI
  document.getElementById('results').classList.remove('active');
  document.getElementById('loader').classList.remove('active');
  if (platform !== 'instamart') {
    document.getElementById('statusText').textContent = 'Select a platform and fetch your orders';
  }
  document.getElementById('statusText').className = 'status-text';
  
  // Check for cached data
  checkCache(platform);
}

function checkCache(platform) {
  const config = PLATFORM_CONFIG[platform];
  const cacheSection = document.getElementById('cacheSection');
  
  chrome.storage.local.get([config.cacheKey, config.lastFetchKey], (data) => {
    if (data[config.cacheKey] && data[config.cacheKey].length > 0 && data[config.lastFetchKey]) {
      const lastFetch = new Date(data[config.lastFetchKey]);
      const now = new Date();
      const hoursDiff = (now - lastFetch) / (1000 * 60 * 60);
      
      if (hoursDiff < 24) {
        // Valid cache exists
        const orders = data[config.cacheKey];
        const total = orders.reduce((sum, o) => sum + o.amount, 0);
        
        const timeAgo = getTimeAgo(lastFetch);
        document.getElementById('cacheHeader').textContent = `📦 Cached data from ${timeAgo}`;
        document.getElementById('cacheSummary').textContent = `${orders.length} orders • ₹${formatIndianNumber(total)}`;
        cacheSection.classList.add('active');
        
        document.getElementById('statusText').textContent = `✅ Cached ${config.name} data available`;
        document.getElementById('statusText').classList.add('success');
      } else {
        cacheSection.classList.remove('active');
      }
    } else {
      cacheSection.classList.remove('active');
    }
  });
}

function getTimeAgo(date) {
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  
  if (diffMins < 60) return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
  return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
}

async function handleFetch() {
  const config = PLATFORM_CONFIG[currentPlatform];
  
  // For Instamart, use Gmail fetch
  if (currentPlatform === 'instamart') {
    await handleInstamartFetch();
    return;
  }
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  // Check if on correct site
  if (!tab.url.includes(config.urlPattern)) {
    document.getElementById('statusText').textContent = `❌ Please navigate to ${config.url} first`;
    document.getElementById('statusText').classList.add('error');
    return;
  }
  
  // Start fetching
  isFetching = true;
  const fetchBtn = document.getElementById('fetchBtn');
  fetchBtn.disabled = true;
  fetchBtn.textContent = 'Fetching...';
  
  // Disable tabs during fetch
  document.getElementById('tabZepto').disabled = true;
  document.getElementById('tabBlinkit').disabled = true;
  document.getElementById('tabInstamart').disabled = true;
  
  document.getElementById('loader').classList.add('active');
  document.getElementById('results').classList.remove('active');
  document.getElementById('cacheSection').classList.remove('active');
  document.getElementById('statusText').textContent = 'Working...';
  document.getElementById('statusText').classList.remove('error', 'success');
  
  // Start progress bar
  ProgressBar.start(currentPlatform);
  ProgressBar.setPhase('connecting', 'Preparing...');
  
  // ALWAYS clear cache before fresh fetch to ensure we get latest data
  await new Promise((resolve) => {
    chrome.storage.local.remove([config.cacheKey, config.lastFetchKey], resolve);
  });
  
  ProgressBar.setPhase('loading', 'Loading orders from page...');
  
  try {
    let orders;
    
    if (currentPlatform === 'zepto') {
      orders = await fetchZeptoOrders(tab.id);
    } else {
      orders = await fetchBlinkitOrders(tab.id);
    }
    
    ProgressBar.setPhase('analyzing', 'Analyzing data...');
    
    if (orders.length === 0) {
      throw new Error('No delivered orders found. Make sure you are logged in.');
    }
    
    // Save to cache
    chrome.storage.local.set({
      [config.cacheKey]: orders,
      [config.lastFetchKey]: new Date().toISOString()
    });
    
    ProgressBar.complete();
    
    displayResults(orders, currentPlatform);
    
    document.getElementById('statusText').textContent = '✅ Data fetched successfully!';
    document.getElementById('statusText').classList.add('success');
    
  } catch (error) {
    ProgressBar.stop();
    document.getElementById('statusText').textContent = `❌ ${error.message}`;
    document.getElementById('statusText').classList.add('error');
  } finally {
    isFetching = false;
    fetchBtn.disabled = false;
    fetchBtn.textContent = '📊 FETCH DETAILS';
    document.getElementById('tabZepto').disabled = false;
    document.getElementById('tabBlinkit').disabled = false;
    document.getElementById('tabInstamart').disabled = false;
    document.getElementById('loader').classList.remove('active');
  }
}

// ============================================
// ZEPTO FETCH LOGIC
// ============================================

async function fetchZeptoOrders(tabId) {
  const result = await chrome.scripting.executeScript({
    target: { tabId },
    func: scrapeZeptoOrdersDOM
  });
  
  if (result && result[0] && result[0].result) {
    if (result[0].result.error) {
      throw new Error(result[0].result.error);
    }
    return result[0].result;
  }
  
  throw new Error('Failed to fetch Zepto orders');
}

// DOM-based scraping for Zepto
async function scrapeZeptoOrdersDOM() {
  const orders = [];
  const seenOrders = new Set();
  
  // Click "Load more" button until it disappears
  async function loadAllOrders() {
    let attempts = 0;
    const maxAttempts = 100; // Increased for users with many orders
    let consecutiveNoButton = 0;
    
    // First scroll to bottom to trigger lazy loading
    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(r => setTimeout(r, 2000));
    
    while (attempts < maxAttempts && consecutiveNoButton < 3) {
      // Scroll down to make sure button is visible
      window.scrollTo(0, document.body.scrollHeight);
      await new Promise(r => setTimeout(r, 500));
      
      // Try multiple selectors for Load more button
      let loadMoreBtn = null;
      
      // Method 1: Find by text content
      const allClickables = Array.from(document.querySelectorAll('button, div[role="button"], span, a'));
      loadMoreBtn = allClickables.find(el => {
        const text = (el.textContent || '').toLowerCase().trim();
        return text === 'load more' || text === 'show more' || text === 'view more';
      });
      
      // Method 2: Find button containing "load" or "more" text
      if (!loadMoreBtn) {
        loadMoreBtn = allClickables.find(el => {
          const text = (el.textContent || '').toLowerCase();
          return (text.includes('load') && text.includes('more')) ||
                 (text.includes('show') && text.includes('more'));
        });
      }
      
      // Method 3: Look for common CSS patterns
      if (!loadMoreBtn) {
        loadMoreBtn = document.querySelector('[class*="load-more"], [class*="loadMore"], [class*="show-more"], [class*="showMore"]');
      }
      
      if (!loadMoreBtn) {
        console.log('[Carthole] No "Load more" button found, attempt:', attempts);
        consecutiveNoButton++;
        await new Promise(r => setTimeout(r, 1000));
        continue;
      }
      
      consecutiveNoButton = 0;
      console.log('[Carthole] Found Load more button, clicking...');
      
      // Scroll button into view
      loadMoreBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await new Promise(r => setTimeout(r, 300));
      
      // Try multiple click methods
      try {
        // Method 1: Direct click
        loadMoreBtn.click();
      } catch (e) {
        console.log('[Carthole] Direct click failed, trying alternatives');
      }
      
      // Method 2: Dispatch mouse events
      try {
        loadMoreBtn.dispatchEvent(new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        }));
      } catch (e) {}
      
      // Method 3: Focus and press Enter
      try {
        loadMoreBtn.focus();
        loadMoreBtn.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
      } catch (e) {}
      
      // Wait for new content to load
      await new Promise(r => setTimeout(r, 2000));
      attempts++;
      
      // Every 10 attempts, do a full page scroll to trigger any lazy loading
      if (attempts % 10 === 0) {
        window.scrollTo(0, 0);
        await new Promise(r => setTimeout(r, 500));
        window.scrollTo(0, document.body.scrollHeight);
        await new Promise(r => setTimeout(r, 1000));
      }
    }
    
    // Final scroll to ensure all content is loaded
    window.scrollTo(0, 0);
    await new Promise(r => setTimeout(r, 500));
    window.scrollTo(0, document.body.scrollHeight);
    await new Promise(r => setTimeout(r, 1500));
    
    console.log('[Carthole] Finished loading orders, attempts:', attempts);
  }
  
  // Parse orders from page
  function parseOrdersFromDOM() {
    const MONTH_MAP = {
      'Jan': 0, 'Feb': 1, 'Mar': 2, 'Apr': 3, 'May': 4, 'Jun': 5,
      'Jul': 6, 'Aug': 7, 'Sep': 8, 'Oct': 9, 'Nov': 10, 'Dec': 11
    };
    
    // Strategy: Find all "Placed at" text nodes, then find nearby amounts
    const allElements = Array.from(document.querySelectorAll('*'));
    
    // First, find all order containers by looking for elements with "Placed at" text
    const dateElements = allElements.filter(el => {
      const text = el.textContent || '';
      const directText = el.innerText || '';
      // Look for elements that directly contain the date pattern (not just in children)
      return directText.match(/Placed at \d{1,2}(st|nd|rd|th)?\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/i) &&
             el.children.length < 5; // Likely a leaf or near-leaf element
    });
    
    console.log('[Carthole] Found', dateElements.length, 'date elements');
    
    dateElements.forEach(dateEl => {
      // Get the order card container (go up to find a reasonable parent)
      let container = dateEl;
      for (let i = 0; i < 8; i++) {
        if (container.parentElement) {
          container = container.parentElement;
          // Stop if we find a container that likely represents one order card
          const containerText = container.innerText || '';
          if (containerText.includes('₹') && 
              (containerText.includes('Order delivered') || containerText.includes('Order cancelled')) &&
              containerText.split('Placed at').length === 2) { // Only one date = one order
            break;
          }
        }
      }
      
      const containerText = container.innerText || '';
      
      // Skip cancelled orders
      if (containerText.includes('Order cancelled') && !containerText.includes('Order delivered')) {
        console.log('[Carthole] Skipping cancelled order');
        return;
      }
      
      // Must be delivered
      if (!containerText.includes('Order delivered')) {
        return;
      }
      
      // Extract date: "Placed at 17th Oct 2025, 12:19 pm"
      const dateMatch = containerText.match(/Placed at (\d{1,2})(?:st|nd|rd|th)?\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{4}),?\s*(\d{1,2}):(\d{2})\s*(am|pm)/i);
      
      // Extract amount: "₹116.37" - find all amounts and take the one that looks like order total
      const amountMatches = containerText.match(/₹[\d,]+(?:\.\d{1,2})?/g);
      
      if (dateMatch && amountMatches && amountMatches.length > 0) {
        const day = parseInt(dateMatch[1]);
        const month = dateMatch[2];
        const year = parseInt(dateMatch[3]);
        let hour = parseInt(dateMatch[4]);
        const minute = parseInt(dateMatch[5]);
        const period = dateMatch[6].toLowerCase();
        
        if (period === 'pm' && hour !== 12) hour += 12;
        if (period === 'am' && hour === 12) hour = 0;
        
        // Get the largest amount (most likely the order total)
        let amount = 0;
        amountMatches.forEach(amtStr => {
          const val = parseFloat(amtStr.replace(/[₹,]/g, ''));
          if (val > amount) amount = val;
        });
        
        const key = `${day}-${month}-${year}-${hour}-${minute}`;
        
        if (!seenOrders.has(key) && amount > 0) {
          seenOrders.add(key);
          
          const date = new Date(year, MONTH_MAP[month], day);
          
          orders.push({
            amount: amount,
            date: `${day} ${month} ${year}, ${dateMatch[4]}:${dateMatch[5]} ${period}`,
            day: day,
            month: month,
            year: year,
            hour: hour,
            dayOfWeek: date.getDay(),
            deliveryTime: 15
          });
          
          console.log('[Carthole] Found order:', amount, day, month, year);
        }
      }
    });
    
    // Fallback: If no orders found, try parsing the whole page text
    if (orders.length === 0) {
      console.log('[Carthole] Using fallback text parsing...');
      
      const pageText = document.body.innerText;
      
      // Split by "Order delivered" to get individual order sections
      const sections = pageText.split(/Order delivered/i);
      
      sections.forEach((section, index) => {
        if (index === 0) return; // Skip text before first order
        
        // Skip if this section is actually a cancelled order
        if (section.toLowerCase().includes('order cancelled')) return;
        
        const dateMatch = section.match(/Placed at (\d{1,2})(?:st|nd|rd|th)?\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{4}),?\s*(\d{1,2}):(\d{2})\s*(am|pm)/i);
        const amountMatch = section.match(/₹([\d,]+(?:\.\d{1,2})?)/);
        
        if (dateMatch && amountMatch) {
          const day = parseInt(dateMatch[1]);
          const month = dateMatch[2];
          const year = parseInt(dateMatch[3]);
          let hour = parseInt(dateMatch[4]);
          const period = dateMatch[6].toLowerCase();
          
          if (period === 'pm' && hour !== 12) hour += 12;
          if (period === 'am' && hour === 12) hour = 0;
          
          const amount = parseFloat(amountMatch[1].replace(/,/g, ''));
          const key = `${day}-${month}-${year}-${hour}`;
          
          if (!seenOrders.has(key) && amount > 0) {
            seenOrders.add(key);
            
            const date = new Date(year, MONTH_MAP[month], day);
            
            orders.push({
              amount: amount,
              date: `${day} ${month} ${year}, ${dateMatch[4]}:${dateMatch[5]} ${period}`,
              day: day,
              month: month,
              year: year,
              hour: hour,
              dayOfWeek: date.getDay(),
              deliveryTime: 15
            });
            
            console.log('[Carthole] Fallback found order:', amount, day, month, year);
          }
        }
      });
    }
  }
  
  try {
    await loadAllOrders();
    await new Promise(r => setTimeout(r, 1000));
    parseOrdersFromDOM();
    
    console.log('[Carthole] Total Zepto orders found:', orders.length);
    
    if (orders.length === 0) {
      return { error: 'No delivered orders found. Make sure you are logged in and have delivered orders.' };
    }
    
    return orders;
    
  } catch (error) {
    console.error('[Carthole] Error:', error);
    return { error: error.message || 'Failed to fetch orders' };
  }
}

// ============================================
// BLINKIT FETCH LOGIC (from Carthole 1.0.0)
// ============================================

async function fetchBlinkitOrders(tabId) {
  // Always navigate to orders page fresh to ensure latest data
  await chrome.tabs.update(tabId, { url: 'https://blinkit.com/account/orders' });
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  const result = await chrome.scripting.executeScript({
    target: { tabId },
    func: scrapeBlinkitOrders
  });
  
  if (result && result[0] && result[0].result) {
    return result[0].result;
  }
  
  throw new Error('Failed to fetch Blinkit orders');
}

async function scrapeBlinkitOrders() {
  const orders = [];
  const seenOrders = new Set();
  
  function parseOrdersFromDOM() {
    const textNodes = [];
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    
    let node;
    while (node = walker.nextNode()) {
      const text = node.textContent.trim();
      if (text) {
        textNodes.push(text);
      }
    }
    
    for (let i = 0; i < textNodes.length; i++) {
      const text = textNodes[i];
      
      // Match both "Arrived in X minutes" AND "Order arrived"
      if (text.match(/^Arrived in \d+ minutes?$/) || text.match(/^Order arrived$/i)) {
        let amount = null;
        let dateInfo = null;
        
        for (let j = i + 1; j < Math.min(i + 30, textNodes.length); j++) {
          const nextText = textNodes[j];
          
          if (!amount && nextText.match(/^₹[\d,]+$/)) {
            amount = parseInt(nextText.replace(/[₹,]/g, ''));
          }
          
          // Match regular date format: "06 Jan, 6:10 pm"
          const dateMatch = nextText.match(/^(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec),\s+(\d{1,2}):(\d{2})\s+(am|pm)$/i);
          
          // Match "Today, 11:30 am" or "Yesterday, 5:00 pm"
          const todayMatch = nextText.match(/^(Today|Yesterday),\s+(\d{1,2}):(\d{2})\s+(am|pm)$/i);
          
          if (!dateInfo && dateMatch) {
            let hours = parseInt(dateMatch[3]);
            const minutes = parseInt(dateMatch[4]);
            const period = dateMatch[5].toLowerCase();
            
            if (period === 'pm' && hours !== 12) hours += 12;
            if (period === 'am' && hours === 12) hours = 0;
            
            dateInfo = {
              date: nextText,
              day: dateMatch[1],
              month: dateMatch[2],
              hour: hours
            };
          } else if (!dateInfo && todayMatch) {
            // Handle "Today" or "Yesterday"
            const now = new Date();
            let targetDate = new Date(now);
            
            if (todayMatch[1].toLowerCase() === 'yesterday') {
              targetDate.setDate(targetDate.getDate() - 1);
            }
            
            let hours = parseInt(todayMatch[2]);
            const period = todayMatch[4].toLowerCase();
            
            if (period === 'pm' && hours !== 12) hours += 12;
            if (period === 'am' && hours === 12) hours = 0;
            
            const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            
            dateInfo = {
              date: nextText,
              day: String(targetDate.getDate()),
              month: monthNames[targetDate.getMonth()],
              hour: hours
            };
          }
          
          if (j > i && (nextText.match(/^Arrived in \d+ minutes?$/) || nextText.match(/^Order arrived$/i))) {
            break;
          }
        }
        
        if (amount && dateInfo) {
          const key = `${dateInfo.date}-${amount}`;
          if (!seenOrders.has(key)) {
            seenOrders.add(key);
            
            // Parse delivery time
            let deliveryMins = 30;
            if (text.match(/^Arrived in (\d+) minutes?$/)) {
              deliveryMins = parseInt(text.match(/^Arrived in (\d+) minutes?$/)[1]);
            }
            
            orders.push({
              amount,
              date: dateInfo.date,
              day: dateInfo.day,
              month: dateInfo.month,
              hour: dateInfo.hour,
              deliveryTime: deliveryMins
            });
          }
        }
      }
    }
  }
  
  async function autoScroll() {
    return new Promise((resolve) => {
      // First scroll to top to ensure fresh start
      window.scrollTo(0, 0);
      
      setTimeout(() => {
        let lastHeight = document.body.scrollHeight;
        let noChangeCount = 0;
        let scrollCount = 0;
        const maxScrolls = 50;
        
        const scrollInterval = setInterval(() => {
          window.scrollTo(0, document.body.scrollHeight);
          scrollCount++;
          
          setTimeout(() => {
            const newHeight = document.body.scrollHeight;
            if (newHeight === lastHeight) {
              noChangeCount++;
            } else {
              noChangeCount = 0;
              lastHeight = newHeight;
            }
            
            if (noChangeCount >= 4 || scrollCount >= maxScrolls) {
              clearInterval(scrollInterval);
              // Scroll to top again, then back to bottom to ensure all content is rendered
              window.scrollTo(0, 0);
              setTimeout(() => {
                window.scrollTo(0, document.body.scrollHeight);
                setTimeout(resolve, 1000);
              }, 500);
            }
          }, 500);
        }, 800);
      }, 500);
    });
  }
  
  try {
    await autoScroll();
    await new Promise(r => setTimeout(r, 500));
    parseOrdersFromDOM();
    
    // Infer years for Blinkit orders
    const now = new Date();
    let year = now.getFullYear();
    let prevMonth = null;
    
    const MONTH_MAP = {
      'Jan': 0, 'Feb': 1, 'Mar': 2, 'Apr': 3, 'May': 4, 'Jun': 5,
      'Jul': 6, 'Aug': 7, 'Sep': 8, 'Oct': 9, 'Nov': 10, 'Dec': 11
    };
    
    const ordersWithYear = orders.map(order => {
      const monthIndex = MONTH_MAP[order.month];
      
      if (prevMonth !== null && monthIndex > prevMonth) {
        year--;
      }
      
      prevMonth = monthIndex;
      
      // Calculate day of week
      const date = new Date(year, monthIndex, parseInt(order.day));
      
      return { 
        ...order, 
        year,
        dayOfWeek: date.getDay()
      };
    });
    
    console.log('[Carthole] Blinkit orders:', ordersWithYear.length);
    return ordersWithYear;
  } catch (error) {
    console.error('[Carthole] Blinkit error:', error);
    return [];
  }
}

// ============================================
// INSTAMART (GMAIL) FETCH LOGIC
// ============================================

async function handleGmailConnect() {
  try {
    document.getElementById('statusText').textContent = 'Connecting to Gmail...';
    document.getElementById('statusText').classList.remove('error', 'success');
    
    // Get OAuth token using Chrome Identity API
    const token = await new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive: true }, (token) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(token);
        }
      });
    });
    
    // Get user's email
    const userInfo = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { 'Authorization': `Bearer ${token}` }
    }).then(r => r.json());
    
    const email = userInfo.email;
    
    // Save token and email
    const config = PLATFORM_CONFIG.instamart;
    await new Promise((resolve) => {
      chrome.storage.local.set({
        [config.gmailTokenKey]: token,
        [config.gmailEmailKey]: email
      }, resolve);
    });
    
    // Update UI
    document.getElementById('gmailConnect').classList.remove('active');
    document.getElementById('gmailConnected').classList.add('active');
    document.getElementById('gmailEmail').textContent = email;
    document.getElementById('fetchBtn').style.display = 'block';
    document.getElementById('fetchBtn').className = 'instamart';
    document.getElementById('fetchBtn').textContent = '🔄 REFRESH DATA';
    
    document.getElementById('statusText').textContent = '✅ Gmail connected! Click Refresh Data to fetch orders.';
    document.getElementById('statusText').classList.add('success');
    
  } catch (error) {
    console.error('[Carthole] Gmail connect error:', error);
    document.getElementById('statusText').textContent = `❌ ${error.message}`;
    document.getElementById('statusText').classList.add('error');
  }
}

async function handleGmailDisconnect() {
  const config = PLATFORM_CONFIG.instamart;
  
  // Get current token to revoke
  const data = await new Promise((resolve) => {
    chrome.storage.local.get([config.gmailTokenKey], resolve);
  });
  
  if (data[config.gmailTokenKey]) {
    const token = data[config.gmailTokenKey];
    
    // Step 1: Revoke token on Google's servers (this is the key fix)
    try {
      await fetch(`https://accounts.google.com/o/oauth2/revoke?token=${token}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      });
      console.log('[Carthole] Token revoked on Google servers');
    } catch (e) {
      console.log('[Carthole] Token revoke API call failed:', e);
    }
    
    // Step 2: Remove from Chrome's cache
    chrome.identity.removeCachedAuthToken({ token });
  }
  
  // Clear stored data
  await new Promise((resolve) => {
    chrome.storage.local.remove([
      config.gmailTokenKey, 
      config.gmailEmailKey, 
      config.cacheKey, 
      config.lastFetchKey
    ], resolve);
  });
  
  // Update UI
  document.getElementById('gmailConnect').classList.add('active');
  document.getElementById('gmailConnected').classList.remove('active');
  document.getElementById('fetchBtn').style.display = 'none';
  document.getElementById('cacheSection').classList.remove('active');
  document.getElementById('results').classList.remove('active');
  
  document.getElementById('statusText').textContent = 'Gmail disconnected. Connect again to fetch orders.';
  document.getElementById('statusText').classList.remove('success', 'error');
}

async function handleInstamartFetch() {
  const config = PLATFORM_CONFIG.instamart;
  
  // Get stored token
  const data = await new Promise((resolve) => {
    chrome.storage.local.get([config.gmailTokenKey], resolve);
  });
  
  if (!data[config.gmailTokenKey]) {
    document.getElementById('statusText').textContent = '❌ Please connect Gmail first';
    document.getElementById('statusText').classList.add('error');
    return;
  }
  
  const token = data[config.gmailTokenKey];
  
  // Start fetching
  isFetching = true;
  const fetchBtn = document.getElementById('fetchBtn');
  fetchBtn.disabled = true;
  fetchBtn.textContent = 'Fetching...';
  
  // Disable tabs
  document.getElementById('tabZepto').disabled = true;
  document.getElementById('tabBlinkit').disabled = true;
  document.getElementById('tabInstamart').disabled = true;
  
  document.getElementById('loader').classList.add('active');
  document.getElementById('results').classList.remove('active');
  document.getElementById('cacheSection').classList.remove('active');
  document.getElementById('statusText').textContent = 'Scanning Gmail...';
  document.getElementById('statusText').classList.remove('error', 'success');
  
  // Start progress bar
  ProgressBar.start('instamart');
  ProgressBar.setPhase('connecting', 'Connecting to Gmail...');
  
  try {
    // Clear old cache
    await new Promise((resolve) => {
      chrome.storage.local.remove([config.cacheKey, config.lastFetchKey], resolve);
    });
    
    ProgressBar.setPhase('searching', 'Searching for Instamart emails...');
    
    // Search for Instamart delivery emails
    const searchQuery = 'from:noreply@swiggy.in subject:Instamart subject:delivered';
    console.log('[Carthole] Gmail search query:', searchQuery);
    const searchUrl = `https://www.googleapis.com/gmail/v1/users/me/messages?q=${encodeURIComponent(searchQuery)}&maxResults=500`;
    
    let allMessageIds = [];
    let nextPageToken = null;
    
    // Paginate through all results
    do {
      const url = nextPageToken 
        ? `${searchUrl}&pageToken=${nextPageToken}`
        : searchUrl;
        
      const response = await fetch(url, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          // Token expired, need to re-authenticate
          chrome.identity.removeCachedAuthToken({ token });
          throw new Error('Session expired. Please disconnect and reconnect Gmail.');
        }
        throw new Error(`Gmail API error: ${response.status}`);
      }
      
      const result = await response.json();
      console.log('[Carthole] Gmail API response:', result);
      
      if (result.messages) {
        allMessageIds = allMessageIds.concat(result.messages.map(m => m.id));
      }
      
      nextPageToken = result.nextPageToken;
      
    } while (nextPageToken);
    
    console.log('[Carthole] Total emails found:', allMessageIds.length);
    
    if (allMessageIds.length === 0) {
      throw new Error('No Instamart delivery emails found in your Gmail.');
    }
    
    ProgressBar.setPhase('processing', 'Processing emails...');
    
    // Fetch each email and parse
    const orders = [];
    let processed = 0;
    let parseFailures = 0;
    
    for (const messageId of allMessageIds) {
      try {
        const msgResponse = await fetch(
          `https://www.googleapis.com/gmail/v1/users/me/messages/${messageId}?format=full`,
          { headers: { 'Authorization': `Bearer ${token}` } }
        );
        
        if (!msgResponse.ok) {
          console.log('[Carthole] Failed to fetch message:', messageId);
          continue;
        }
        
        const msgData = await msgResponse.json();
        const order = parseInstamartEmail(msgData);
        
        if (order) {
          orders.push(order);
        } else {
          parseFailures++;
        }
        
        processed++;
        
        // Update progress based on completion percentage
        const pct = (processed / allMessageIds.length) * 100;
        if (pct < 50) {
          ProgressBar.setPhase('processing', 'Processing emails...');
        } else if (pct < 80) {
          ProgressBar.setPhase('analyzing', 'Analyzing orders...');
        } else {
          ProgressBar.setPhase('finalizing', 'Almost done...');
        }
        
      } catch (e) {
        console.error('[Carthole] Error parsing email:', e);
        parseFailures++;
      }
    }
    
    console.log('[Carthole] Parsing complete. Orders:', orders.length, 'Failures:', parseFailures);
    
    if (orders.length === 0) {
      throw new Error(`Could not parse any order data from ${allMessageIds.length} emails. Check console for details.`);
    }
    
    // Sort by date (newest first)
    orders.sort((a, b) => new Date(b.rawDate) - new Date(a.rawDate));
    
    // Save to cache
    chrome.storage.local.set({
      [config.cacheKey]: orders,
      [config.lastFetchKey]: new Date().toISOString()
    });
    
    ProgressBar.complete();
    
    displayResults(orders, currentPlatform);
    
    document.getElementById('statusText').textContent = `✅ Found ${orders.length} Instamart orders!`;
    document.getElementById('statusText').classList.add('success');
    
  } catch (error) {
    console.error('[Carthole] Instamart fetch error:', error);
    ProgressBar.stop();
    document.getElementById('statusText').textContent = `❌ ${error.message}`;
    document.getElementById('statusText').classList.add('error');
  } finally {
    isFetching = false;
    fetchBtn.disabled = false;
    fetchBtn.textContent = '🔄 REFRESH DATA';
    document.getElementById('tabZepto').disabled = false;
    document.getElementById('tabBlinkit').disabled = false;
    document.getElementById('tabInstamart').disabled = false;
    document.getElementById('loader').classList.remove('active');
  }
}

function parseInstamartEmail(msgData) {
  try {
    // Get email date from headers
    const headers = msgData.payload.headers;
    const dateHeader = headers.find(h => h.name.toLowerCase() === 'date');
    const subjectHeader = headers.find(h => h.name.toLowerCase() === 'subject');
    
    if (!dateHeader) {
      console.log('[Carthole] No date header found');
      return null;
    }
    
    // Check subject contains "Instamart" and "delivered"
    const subject = subjectHeader ? subjectHeader.value.toLowerCase() : '';
    if (!subject.includes('instamart') || !subject.includes('delivered')) {
      console.log('[Carthole] Subject does not match:', subject);
      return null;
    }
    
    // Parse date
    const emailDate = new Date(dateHeader.value);
    if (isNaN(emailDate.getTime())) {
      console.log('[Carthole] Invalid date:', dateHeader.value);
      return null;
    }
    
    // Get email body
    let body = '';
    
    function extractBody(part) {
      if (part.body && part.body.data) {
        try {
          const decoded = atob(part.body.data.replace(/-/g, '+').replace(/_/g, '/'));
          body += decoded;
        } catch (e) {
          console.log('[Carthole] Base64 decode error:', e);
        }
      }
      if (part.parts) {
        part.parts.forEach(extractBody);
      }
    }
    
    extractBody(msgData.payload);
    
    // Decode HTML entities
    function decodeHTMLEntities(text) {
      const entities = {
        '&#8377;': '₹',
        '&#x20B9;': '₹',
        '&amp;': '&',
        '&nbsp;': ' ',
        '&lt;': '<',
        '&gt;': '>',
        '&quot;': '"',
        '&#39;': "'",
        '₹': '₹'
      };
      
      let decoded = text;
      for (const [entity, char] of Object.entries(entities)) {
        decoded = decoded.split(entity).join(char);
      }
      
      // Also handle numeric entities
      decoded = decoded.replace(/&#(\d+);/g, (match, num) => String.fromCharCode(num));
      decoded = decoded.replace(/&#x([0-9A-Fa-f]+);/g, (match, hex) => String.fromCharCode(parseInt(hex, 16)));
      
      return decoded;
    }
    
    // Strip HTML tags and decode entities
    let plainBody = decodeHTMLEntities(body);
    plainBody = plainBody.replace(/<[^>]*>/g, ' '); // Remove HTML tags
    plainBody = plainBody.replace(/\s+/g, ' '); // Normalize whitespace
    
    console.log('[Carthole] Processing email, body snippet:', plainBody.substring(0, 500));
    
    // Try multiple patterns to find Grand Total
    let amount = null;
    
    // Pattern 1: Grand Total followed by rupee symbol and amount
    const patterns = [
      /Grand\s*Total[:\s]*[₹Rs.]*\s*([\d,]+(?:\.\d{1,2})?)/i,
      /Grand\s*Total[^0-9₹]*[₹Rs.]*\s*([\d,]+(?:\.\d{1,2})?)/i,
      /GrandTotal[:\s]*[₹Rs.]*\s*([\d,]+(?:\.\d{1,2})?)/i,
      /Grand Total.*?(\d{2,}(?:\.\d{1,2})?)/i,
      /total[:\s]*[₹Rs.]*\s*([\d,]+\.\d{2})\s*(?:$|Disclaimer)/i
    ];
    
    for (const pattern of patterns) {
      const match = plainBody.match(pattern);
      if (match) {
        const parsed = parseFloat(match[1].replace(/,/g, ''));
        if (!isNaN(parsed) && parsed > 0 && parsed < 100000) { // Sanity check
          amount = parsed;
          console.log('[Carthole] Found amount:', amount, 'with pattern:', pattern);
          break;
        }
      }
    }
    
    // Fallback: Look for the last occurrence of ₹XXX.XX pattern which is usually Grand Total
    if (!amount) {
      const allAmounts = plainBody.match(/[₹Rs.]\s*([\d,]+\.\d{2})/g);
      if (allAmounts && allAmounts.length > 0) {
        // Get the last amount (usually Grand Total)
        const lastAmount = allAmounts[allAmounts.length - 1];
        const parsed = parseFloat(lastAmount.replace(/[₹Rs.,\s]/g, ''));
        if (!isNaN(parsed) && parsed > 0) {
          amount = parsed;
          console.log('[Carthole] Fallback amount:', amount);
        }
      }
    }
    
    if (!amount) {
      console.log('[Carthole] Could not find amount in email');
      return null;
    }
    
    // Extract order ID from subject
    const orderIdMatch = subject.match(/#?(\d{12,})/);
    const orderId = orderIdMatch ? orderIdMatch[1] : null;
    
    // Build order object
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    console.log('[Carthole] Successfully parsed order:', amount, emailDate);
    
    return {
      date: `${emailDate.getDate()} ${monthNames[emailDate.getMonth()]} ${emailDate.getFullYear()}`,
      day: String(emailDate.getDate()),
      month: monthNames[emailDate.getMonth()],
      year: emailDate.getFullYear(),
      hour: emailDate.getHours(),
      dayOfWeek: emailDate.getDay(), // 0 = Sunday, 6 = Saturday
      amount: amount,
      orderId: orderId,
      rawDate: emailDate.toISOString(),
      deliveryTime: null // Not available from emails
    };
    
  } catch (e) {
    console.error('[Carthole] Email parse error:', e);
    return null;
  }
}

// ============================================
// ANALYTICS COMPUTATION
// ============================================

function computeAnalytics(orders, platform) {
  // Basic stats
  const totalSpend = orders.reduce((sum, o) => sum + o.amount, 0);
  const totalOrders = orders.length;
  const avgOrder = totalOrders > 0 ? totalSpend / totalOrders : 0;
  
  // Monthly breakdown
  const monthlyTotals = {};
  orders.forEach(order => {
    const key = `${order.month}${String(order.year).slice(2)}`;
    if (!monthlyTotals[key]) {
      monthlyTotals[key] = { amount: 0, count: 0, year: order.year, monthIndex: MONTH_MAP[order.month] };
    }
    monthlyTotals[key].amount += order.amount;
    monthlyTotals[key].count++;
  });
  
  // Day of week analysis
  const dayStats = Array(7).fill(null).map(() => ({ amount: 0, count: 0 }));
  orders.forEach(order => {
    const dayIndex = order.dayOfWeek;
    dayStats[dayIndex].amount += order.amount;
    dayStats[dayIndex].count++;
  });
  
  let highestSpendDay = { day: 0, amount: 0 };
  let mostFrequentDay = { day: 0, count: 0 };
  let highestAvgDay = { day: 0, avg: 0 };
  
  dayStats.forEach((stat, i) => {
    if (stat.amount > highestSpendDay.amount) {
      highestSpendDay = { day: i, amount: stat.amount };
    }
    if (stat.count > mostFrequentDay.count) {
      mostFrequentDay = { day: i, count: stat.count };
    }
    const avg = stat.count > 0 ? stat.amount / stat.count : 0;
    if (avg > highestAvgDay.avg) {
      highestAvgDay = { day: i, avg };
    }
  });
  
  // Weekend vs Weekday
  const weekend = { amount: 0, count: 0 };
  const weekday = { amount: 0, count: 0 };
  
  orders.forEach(order => {
    const dayIndex = order.dayOfWeek;
    if (dayIndex === 0 || dayIndex === 6) {
      weekend.amount += order.amount;
      weekend.count++;
    } else {
      weekday.amount += order.amount;
      weekday.count++;
    }
  });
  
  // Time analysis
  const timeStats = {
    Morning: { amount: 0, count: 0 },
    Afternoon: { amount: 0, count: 0 },
    Evening: { amount: 0, count: 0 },
    Night: { amount: 0, count: 0 }
  };
  
  orders.forEach(order => {
    const hour = order.hour;
    let slot;
    if (hour >= 6 && hour < 12) slot = 'Morning';
    else if (hour >= 12 && hour < 17) slot = 'Afternoon';
    else if (hour >= 17 && hour < 21) slot = 'Evening';
    else slot = 'Night';
    
    timeStats[slot].amount += order.amount;
    timeStats[slot].count++;
  });
  
  let peakSlot = 'Evening';
  let peakCount = 0;
  Object.entries(timeStats).forEach(([slot, stat]) => {
    if (stat.count > peakCount) {
      peakCount = stat.count;
      peakSlot = slot;
    }
  });
  
  // Delivery stats
  const deliveryTimes = orders.map(o => o.deliveryTime).filter(t => t > 0);
  const avgDelivery = deliveryTimes.length > 0 ? deliveryTimes.reduce((a, b) => a + b, 0) / deliveryTimes.length : 0;
  const fastestDelivery = deliveryTimes.length > 0 ? Math.min(...deliveryTimes) : 0;
  const slowestDelivery = deliveryTimes.length > 0 ? Math.max(...deliveryTimes) : 0;
  
  // Spending insights
  const amounts = orders.map(o => o.amount);
  const highestOrder = amounts.length > 0 ? Math.max(...amounts) : 0;
  const lowestOrder = amounts.length > 0 ? Math.min(...amounts) : 0;
  const ordersAboveAvg = orders.filter(o => o.amount > avgOrder).length;
  const ordersAboveAvgPercent = totalOrders > 0 ? Math.round((ordersAboveAvg / totalOrders) * 100) : 0;
  
  return {
    platform,
    totalSpend,
    totalOrders,
    avgOrder,
    monthlyTotals,
    dayStats,
    highestSpendDay,
    mostFrequentDay,
    highestAvgDay,
    weekend,
    weekday,
    timeStats,
    peakSlot,
    avgDelivery,
    fastestDelivery,
    slowestDelivery,
    highestOrder,
    lowestOrder,
    ordersAboveAvg,
    ordersAboveAvgPercent,
    orders
  };
}

// ============================================
// DISPLAY RESULTS
// ============================================

function displayResults(orders, platform) {
  const data = computeAnalytics(orders, platform);
  computedData = data;
  
  // Quick Stats
  document.getElementById('totalSpend').textContent = `₹${formatIndianNumber(data.totalSpend)}`;
  document.getElementById('totalOrders').textContent = data.totalOrders;
  document.getElementById('avgOrder').textContent = `₹${formatIndianNumber(data.avgOrder)}`;
  
  // Day Analysis
  document.getElementById('highestSpendDay').textContent = 
    `${DAY_NAMES[data.highestSpendDay.day]} (₹${formatIndianNumber(data.highestSpendDay.amount)})`;
  document.getElementById('mostFrequentDay').textContent = 
    `${DAY_NAMES[data.mostFrequentDay.day]} (${data.mostFrequentDay.count} orders)`;
  document.getElementById('highestAvgDay').textContent = 
    `${DAY_NAMES[data.highestAvgDay.day]} (₹${formatIndianNumber(data.highestAvgDay.avg)})`;
  
  // Weekend vs Weekday
  document.getElementById('weekendAmount').textContent = `₹${formatIndianNumber(data.weekend.amount)}`;
  document.getElementById('weekendDetail').textContent = 
    `${data.weekend.count} orders • avg ₹${formatIndianNumber(data.weekend.count > 0 ? data.weekend.amount / data.weekend.count : 0)}`;
  document.getElementById('weekdayAmount').textContent = `₹${formatIndianNumber(data.weekday.amount)}`;
  document.getElementById('weekdayDetail').textContent = 
    `${data.weekday.count} orders • avg ₹${formatIndianNumber(data.weekday.count > 0 ? data.weekday.amount / data.weekday.count : 0)}`;
  
  // Time Analysis
  const slots = ['Morning', 'Afternoon', 'Evening', 'Night'];
  const slotIds = ['slotMorning', 'slotAfternoon', 'slotEvening', 'slotNight'];
  
  slots.forEach((slot, i) => {
    const el = document.getElementById(slotIds[i]);
    const stat = data.timeStats[slot];
    
    el.querySelector('.time-slot-value').textContent = `₹${formatIndianNumber(stat.amount)}`;
    el.querySelector('.time-slot-orders').textContent = `${stat.count} orders`;
    
    if (slot === data.peakSlot) {
      el.classList.add('peak');
      if (!el.querySelector('.peak-badge')) {
        const badge = document.createElement('span');
        badge.className = 'peak-badge';
        badge.textContent = 'PEAK';
        el.appendChild(badge);
      }
    } else {
      el.classList.remove('peak');
      const existingBadge = el.querySelector('.peak-badge');
      if (existingBadge) existingBadge.remove();
    }
  });
  
  // Delivery Stats - Only show for Blinkit (Zepto and Instamart don't have this data)
  const deliveryStatsCard = document.getElementById('deliveryStatsCard');
  if (platform === 'zepto' || platform === 'instamart') {
    deliveryStatsCard.style.display = 'none';
  } else {
    deliveryStatsCard.style.display = 'block';
    document.getElementById('avgDelivery').textContent = `${data.avgDelivery.toFixed(1)} mins`;
    document.getElementById('fastestDelivery').textContent = `${data.fastestDelivery} mins`;
    document.getElementById('slowestDelivery').textContent = `${data.slowestDelivery} mins`;
  }
  
  // Spending Insights
  document.getElementById('avgOrderInsight').textContent = `₹${formatIndianNumber(data.avgOrder)}`;
  document.getElementById('highestOrder').textContent = `₹${formatIndianNumber(data.highestOrder)}`;
  document.getElementById('lowestOrder').textContent = `₹${formatIndianNumber(data.lowestOrder)}`;
  document.getElementById('ordersAboveAvg').textContent = `${data.ordersAboveAvg} (${data.ordersAboveAvgPercent}%)`;
  
  // Monthly Data
  const sorted = Object.entries(data.monthlyTotals).sort((a, b) => {
    const yearDiff = b[1].year - a[1].year;
    if (yearDiff !== 0) return yearDiff;
    return b[1].monthIndex - a[1].monthIndex;
  });
  
  const monthlyData = document.getElementById('monthlyData');
  monthlyData.innerHTML = sorted.map(([key, stat]) => `
    <div class="month-row">
      <span class="month-name">${key}</span>
      <span class="month-orders">#${stat.count}</span>
      <span class="month-amount">₹${formatIndianNumber(stat.amount)}</span>
    </div>
  `).join('');
  
  // Totals
  document.getElementById('totalOrdersBottom').textContent = `#${data.totalOrders}`;
  document.getElementById('grandTotal').textContent = `₹${formatIndianNumber(data.totalSpend)}`;
  
  // Update platform-specific styling
  document.getElementById('totalRow').className = 'total-row ' + platform;
  document.getElementById('downloadBtn').className = 'download-btn ' + platform;
  
  // Show results
  document.getElementById('results').classList.add('active');
  document.getElementById('cacheSection').classList.remove('active');
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function formatIndianNumber(num) {
  const str = Math.round(num).toString();
  if (str.length <= 3) return str;
  
  let result = '';
  let count = 0;
  
  for (let i = str.length - 1; i >= 0; i--) {
    result = str[i] + result;
    count++;
    
    if (i > 0) {
      if (count === 3 && str.length > 3) {
        result = ',' + result;
      } else if (count > 3 && (count - 3) % 2 === 0) {
        result = ',' + result;
      }
    }
  }
  
  return result;
}

// ============================================
// CSV DOWNLOAD
// ============================================

function downloadCSV(data, platform) {
  const config = PLATFORM_CONFIG[platform];
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0];
  
  // Helper to format numbers for CSV - plain numbers only, rounded to 2 decimals
  const num = (value) => Math.round(value * 100) / 100;
  
  let csv = '';
  
  // Header
  csv += `CARTHOLE - ${config.name.toUpperCase()} EXPENSE REPORT\n`;
  csv += `Generated on,${now.toLocaleString()}\n\n`;
  
  // Summary
  csv += 'SUMMARY\n';
  csv += `Total Spend (INR),${num(data.totalSpend)}\n`;
  csv += `Total Orders,${data.totalOrders}\n`;
  csv += `Average Order (INR),${num(data.avgOrder)}\n\n`;
  
  // Monthly Breakdown
  csv += 'MONTHLY BREAKDOWN\n';
  csv += 'Month,Orders,Amount (INR)\n';
  
  const sorted = Object.entries(data.monthlyTotals).sort((a, b) => {
    const yearDiff = b[1].year - a[1].year;
    if (yearDiff !== 0) return yearDiff;
    return b[1].monthIndex - a[1].monthIndex;
  });
  
  sorted.forEach(([key, stat]) => {
    csv += `${key},${stat.count},${num(stat.amount)}\n`;
  });
  csv += `TOTAL,${data.totalOrders},${num(data.totalSpend)}\n\n`;
  
  // Day Analysis
  csv += 'DAY ANALYSIS\n';
  csv += 'Day,Orders,Amount (INR),Average (INR)\n';
  DAY_NAMES.forEach((day, i) => {
    const stat = data.dayStats[i];
    const avg = stat.count > 0 ? stat.amount / stat.count : 0;
    csv += `${day},${stat.count},${num(stat.amount)},${num(avg)}\n`;
  });
  csv += '\n';
  
  csv += 'DAY INSIGHTS\n';
  csv += `Highest Spending Day,${DAY_NAMES[data.highestSpendDay.day]},${num(data.highestSpendDay.amount)}\n`;
  csv += `Most Frequent Day,${DAY_NAMES[data.mostFrequentDay.day]},${data.mostFrequentDay.count} orders\n`;
  csv += `Highest Avg Order Day,${DAY_NAMES[data.highestAvgDay.day]},${num(data.highestAvgDay.avg)}\n\n`;
  
  // Weekend vs Weekday
  csv += 'WEEKEND VS WEEKDAY\n';
  csv += 'Type,Orders,Amount (INR),Average (INR)\n';
  const weekendAvg = data.weekend.count > 0 ? data.weekend.amount / data.weekend.count : 0;
  const weekdayAvg = data.weekday.count > 0 ? data.weekday.amount / data.weekday.count : 0;
  csv += `Weekend,${data.weekend.count},${num(data.weekend.amount)},${num(weekendAvg)}\n`;
  csv += `Weekday,${data.weekday.count},${num(data.weekday.amount)},${num(weekdayAvg)}\n\n`;
  
  // Time Analysis
  csv += 'TIME ANALYSIS\n';
  csv += 'Time Slot,Range,Orders,Amount (INR)\n';
  const timeRanges = {
    Morning: '6am-12pm',
    Afternoon: '12pm-5pm',
    Evening: '5pm-9pm',
    Night: '9pm-12am'
  };
  Object.entries(data.timeStats).forEach(([slot, stat]) => {
    const isPeak = slot === data.peakSlot ? ' (PEAK)' : '';
    csv += `${slot}${isPeak},${timeRanges[slot]},${stat.count},${num(stat.amount)}\n`;
  });
  csv += '\n';
  
  // Delivery Stats - Only for Blinkit
  if (platform === 'blinkit') {
    csv += 'DELIVERY STATS\n';
    csv += `Average Delivery (mins),${num(data.avgDelivery)}\n`;
    csv += `Fastest Delivery (mins),${data.fastestDelivery}\n`;
    csv += `Slowest Delivery (mins),${data.slowestDelivery}\n\n`;
  }
  
  // Spending Insights
  csv += 'SPENDING INSIGHTS\n';
  csv += `Highest Single Order (INR),${num(data.highestOrder)}\n`;
  csv += `Lowest Single Order (INR),${num(data.lowestOrder)}\n`;
  csv += `Orders Above Average,${data.ordersAboveAvg} (${data.ordersAboveAvgPercent}%)\n`;
  
  // Download
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `carthole-${platform}-${dateStr}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}
